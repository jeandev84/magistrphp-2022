<?php
namespace App\Controllers;

use Specialist\Controller;


class HomeController extends Controller
{

     public function index()
     {

     }
}