<?php

return [
  'root' => realpath(__DIR__.'/../'),
  'name' => 'Интернет Магазина',
  'database' => [
      'host' => 'localhost',
      'username' => 'brown',
      'password' => 'secret123456',
      'database' => 'specialist_oop_eshop'
  ],
  'view.path' => 'views'
];