<?php
namespace Specialist\Http\Session;

interface SessionInterface
{

}