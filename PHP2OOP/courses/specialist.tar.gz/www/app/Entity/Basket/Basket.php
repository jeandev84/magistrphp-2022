<?php
namespace App\Entity\Basket;

class Basket
{

}