<?php
namespace Specialist\Routing\Exception;

class RouteException extends \Exception
{

}