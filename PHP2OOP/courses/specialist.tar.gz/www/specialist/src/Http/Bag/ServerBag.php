<?php
namespace Specialist\Http\Bag;

class ServerBag extends ParameterBag
{

}