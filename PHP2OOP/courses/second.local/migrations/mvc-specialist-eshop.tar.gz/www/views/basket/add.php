<form action="/book/add" method="POST">
    <div class="mb-3">
        <label for="title" >Название</label>
        <input type="text"  class="form-control" name="title" id="title" value="">
    </div>
    <div class="mb-3">
        <label for="price" >Цена</label>
        <input type="text"  class="form-control" name="price" id="price" value="">
    </div>
    <div class="mb-3">
        <input  class="btn btn-primary mb-3" type="submit">
    </div>
</form>