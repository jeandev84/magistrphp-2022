<?php
namespace Specialist\Http\Bag;

class CookieBag extends ParameterBag
{

}