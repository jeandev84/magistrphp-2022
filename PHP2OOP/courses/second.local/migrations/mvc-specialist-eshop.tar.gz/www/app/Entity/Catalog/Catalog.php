<?php
namespace App\Entity\Catalog;

class Catalog
{

}