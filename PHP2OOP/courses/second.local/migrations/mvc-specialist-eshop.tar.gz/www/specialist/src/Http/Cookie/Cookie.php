<?php
namespace Specialist\Http\Cookie;

class Cookie
{


}