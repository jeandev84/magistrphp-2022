<?php
namespace Specialist\Http\Bag;

class FileBag extends ParameterBag
{

}