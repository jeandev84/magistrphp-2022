<?php
namespace Specialist\Http\Bag;


class InputBag extends ParameterBag
{

}