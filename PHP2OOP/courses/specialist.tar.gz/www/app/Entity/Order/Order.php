<?php
namespace App\Entity\Order;

class Order
{

}