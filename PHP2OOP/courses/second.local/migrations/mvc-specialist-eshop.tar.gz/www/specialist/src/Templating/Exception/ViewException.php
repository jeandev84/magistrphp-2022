<?php
namespace Specialist\Templating\Exception;

class ViewException extends \Exception
{

}