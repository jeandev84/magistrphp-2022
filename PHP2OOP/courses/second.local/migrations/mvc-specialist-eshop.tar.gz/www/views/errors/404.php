<h1><?= $title ?></h1>
<p>Oops! Something went wrong...</p>