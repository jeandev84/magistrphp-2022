<?php
namespace Specialist\Database\ORM;

class Model
{

}