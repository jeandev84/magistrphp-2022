### php -v
### composer -v   (2.1.14)
### composer self-update  (2.2.5) композер обновляет сам себя до последняя версии
### composer self-update --rollback (2.1.14) откатывает версии композер на предыдущую весрсии
### composer init

### Install packages
### composer install (установить зависимость)
### composer update (обновить зависимости)


### Faker
### composer require fakerphp/faker


### composer dump-autoload -o



