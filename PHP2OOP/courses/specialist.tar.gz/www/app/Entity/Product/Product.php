<?php
namespace App\Entity\Product;

class Product
{

}